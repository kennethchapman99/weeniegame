#!/usr/bin/env python3
"""
Backyard Map-Based Greybox Planner importer.

This is NOT a photo-wall importer. It does three things:

  1. Prepares MAP assets for Unity:
       - copies  "Backyard - Aerial.png"  -> Reference/BackyardCapture/Map/Backyard_Aerial.png
       - converts "export_map.HEIC"        -> Reference/BackyardCapture/Map/export_map.png  (via sips)

  2. Indexes the numbered reference photos as REFERENCE LINKS (it does not copy the
     multi-megabyte originals into the Unity project). Photos are grouped by their
     LEADING filename number into capture points and tagged for gameplay candidates.

  3. Emits structured data the Unity editor tool turns into an editable greybox scene:
       - Reference/BackyardCapture/backyard_manifest.json   (per-image index)
       - Reference/BackyardCapture/backyard_manifest.md     (human summary)
       - Reference/BackyardCapture/backyard_capture_points.json  (per-point placement data)
       - Reference/BackyardCapture/contact_sheets/*.html    (external browser contact sheets)

The capture-points file is MERGED on rerun: manually placed marker positions are preserved.
"""
from pathlib import Path
import argparse
import datetime
import html
import json
import os
import re
import shutil
import subprocess
import sys

PHOTO_EXTS = {'.jpg', '.jpeg', '.png'}

# Leading filename number -> capture point. Anything without a leading number is "ungrouped".
LEADING_NUMBER = re.compile(r'^(\d+)')

# Direction keyword -> canonical direction.
DIRECTION_KEYWORDS = {
    'forward': 'forward', 'forwards': 'forward', 'front': 'forward', 'ahead': 'forward',
    'backward': 'backward', 'backwards': 'backward', 'back': 'backward', 'rear': 'backward',
    'left': 'left', 'right': 'right',
}

# Layout / scale validation views.
OVERVIEW_KEYWORDS = {'high', 'overview', 'overhead', 'top', 'wide', 'aerial'}
DOGVIEW_KEYWORDS = {'dogview', 'dog', 'low', 'route', 'runlane'}

# Gameplay-candidate keyword -> tag. These drive greybox zones and interactive candidates.
GAMEPLAY_KEYWORDS = {
    'tunnel': 'tunnel', 'crawl': 'tunnel', 'squeeze': 'tunnel', 'under': 'tunnel',
    'hide': 'hide', 'hiding': 'hide',
    'cover': 'cover', 'shadow': 'cover',
    'shrub': 'shrub', 'bush': 'shrub', 'hedge': 'shrub', 'ivy': 'shrub', 'garden': 'shrub',
    'fence': 'fence',
    'gate': 'gate', 'latch': 'gate', 'gap': 'gate',
    'dig': 'dig', 'dirt': 'dig', 'soil': 'dig', 'mulch': 'dig',
    'patio': 'patio', 'paver': 'patio', 'stone': 'patio',
    'deck': 'deck', 'stairs': 'deck', 'step': 'deck', 'railing': 'deck',
    'tree': 'tree', 'trunk': 'tree', 'branch': 'tree', 'magnolia': 'tree',
}

# Tags that mark a point as carrying an interactive-candidate (cover / route / dig / etc.).
INTERACTIVE_TAGS = {'tunnel', 'hide', 'cover', 'fence', 'gate', 'dig', 'shrub'}


def tokens(stem):
    return [t for t in re.split(r'[^a-zA-Z0-9]+', stem.lower()) if t]


def natural_key(p):
    return [int(x) if x.isdigit() else x for x in re.split(r'(\d+)', p.name.lower())]


def point_id_for(name):
    """Group by the LEADING number only. '1_high.jpg' -> point_001. 'IMG_2026...' -> None."""
    m = LEADING_NUMBER.match(name)
    if not m:
        return None
    return f'point_{int(m.group(1)):03d}'


def classify(tk):
    """Return (view_type, direction, tags, gameplay_candidates) for a token list."""
    ss = set(tk)
    direction = ''
    for token in tk:  # first direction token wins, in filename order
        if token in DIRECTION_KEYWORDS:
            direction = DIRECTION_KEYWORDS[token]
            break

    if ss & OVERVIEW_KEYWORDS:
        view_type = 'overview_high'
    elif ss & DOGVIEW_KEYWORDS:
        view_type = 'dogview_route'
    else:
        view_type = 'unknown'

    gameplay = sorted({GAMEPLAY_KEYWORDS[t] for t in tk if t in GAMEPLAY_KEYWORDS})

    tags = set(gameplay)
    if view_type == 'overview_high':
        tags.update({'overview', 'layout'})
    if view_type == 'dogview_route':
        tags.add('dogview')

    return view_type, direction, sorted(tags or {'reference'}), gameplay


def scan_photos(src):
    return sorted(
        (p for p in src.iterdir() if p.is_file() and p.suffix.lower() in PHOTO_EXTS),
        key=natural_key,
    )


def convert_heic_to_png(src_heic, dest_png):
    """Convert HEIC -> PNG with macOS sips. Returns True on success."""
    if not src_heic.exists():
        return False, f'annotated map not found: {src_heic}'
    if shutil.which('sips') is None:
        return False, 'sips not available (not on macOS?)'
    dest_png.parent.mkdir(parents=True, exist_ok=True)
    try:
        subprocess.run(
            ['sips', '-s', 'format', 'png', str(src_heic), '--out', str(dest_png)],
            check=True, capture_output=True, text=True,
        )
        return (dest_png.exists(), None if dest_png.exists() else 'sips reported success but no file')
    except subprocess.CalledProcessError as e:
        return False, (e.stderr or e.stdout or str(e)).strip()


def image_pixel_size(path):
    """Read pixel dimensions via sips (best-effort)."""
    if shutil.which('sips') is None or not path.exists():
        return None
    try:
        out = subprocess.run(['sips', '-g', 'pixelWidth', '-g', 'pixelHeight', str(path)],
                             check=True, capture_output=True, text=True).stdout
        w = re.search(r'pixelWidth:\s*(\d+)', out)
        h = re.search(r'pixelHeight:\s*(\d+)', out)
        if w and h:
            return int(w.group(1)), int(h.group(1))
    except subprocess.CalledProcessError:
        pass
    return None


def write_manifest_md(path, manifest):
    lines = [
        '# Backyard Capture Manifest',
        '',
        f'Generated: `{manifest["generated_at"]}`',
        '',
        f'Source photos: `{manifest["source_root"]}`',
        '',
        f'Images indexed: **{len(manifest["images"])}**  |  Capture points: **{len(manifest["points"])}**',
        '',
        '> Photos are referenced in place — they are NOT copied into the Unity project.',
        '',
        '| Point | File | View | Direction | Tags |',
        '|---|---|---|---|---|',
    ]
    for img in manifest['images']:
        lines.append(
            f'| {img["point_id"]} | {img["filename"]} | {img["type"]} | '
            f'{img["direction"] or "-"} | {", ".join(img["tags"])} |'
        )
    path.write_text('\n'.join(lines) + '\n', encoding='utf-8')


def write_contact_sheet(path, title, images):
    """External browser contact sheet. References ORIGINAL photos by relative path."""
    figures = []
    for img in images:
        rel = os.path.relpath(img['original_file'], path.parent).replace(os.sep, '/')
        caption = (
            f'<b>{html.escape(img["point_id"] or "ungrouped")}</b><br>'
            f'{html.escape(img["filename"])}<br>'
            f'<small>{html.escape(img["type"])}'
            f'{" / " + html.escape(img["direction"]) if img["direction"] else ""}</small><br>'
            f'<small>{html.escape(", ".join(img["tags"]))}</small>'
        )
        figures.append(
            f'<figure><a href="{html.escape(rel)}" target="_blank">'
            f'<img src="{html.escape(rel)}" loading="lazy"></a>'
            f'<figcaption>{caption}</figcaption></figure>'
        )
    style = (
        'body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;margin:24px}'
        '.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:16px}'
        'figure{margin:0;border:1px solid #ccc;padding:8px;border-radius:8px;background:#fafafa}'
        'img{width:100%;height:150px;object-fit:cover;border-radius:4px}'
        'figcaption{font-size:12px;line-height:1.35;margin-top:6px;overflow-wrap:anywhere}'
    )
    path.write_text(
        f'<!doctype html><meta charset="utf-8"><title>{html.escape(title)}</title>'
        f'<style>{style}</style><h1>{html.escape(title)}</h1>'
        f'<p>{len(images)} images — links point at the original photos in MAPS - template.</p>'
        f'<div class="grid">{"".join(figures)}</div>',
        encoding='utf-8',
    )


def build_points(images, existing_points):
    """Aggregate images into capture points, preserving placement from a prior file."""
    prior = {p['id']: p for p in existing_points}
    by_point = {}
    for img in images:
        if not img['point_id']:
            continue
        by_point.setdefault(img['point_id'], []).append(img)

    points = []
    for staging_index, pid in enumerate(sorted(by_point)):
        entries = by_point[pid]
        tags, candidates, types, directions = set(), set(), set(), set()
        for e in entries:
            tags.update(e['tags'])
            candidates.update(e['gameplay_candidates'])
            types.add(e['type'])
            if e['direction']:
                directions.add(e['direction'])
        prev = prior.get(pid)
        map_position = prev['map_position'] if prev and 'map_position' in prev else {
            'x': 0.0, 'y': 0.0, 'placed': False,
        }
        points.append({
            'id': pid,
            'images': sorted(e['filename'] for e in entries),
            'types': sorted(types),
            'directions': sorted(directions),
            'tags': sorted(tags),
            'gameplay_candidates': sorted(candidates),
            'interactive': bool(candidates & INTERACTIVE_TAGS),
            'staging_index': prev.get('staging_index', staging_index) if prev else staging_index,
            'map_position': map_position,
        })
    return points


def main():
    ap = argparse.ArgumentParser(description='Backyard map-based greybox planner importer')
    ap.add_argument('--source', default='MAPS - template/01_exports_flat',
                    help='folder of numbered reference photos')
    ap.add_argument('--aerial', default='MAPS - template/Backyard - Aerial.png',
                    help='top-down aerial map PNG (layout underlay)')
    ap.add_argument('--annotated', default='MAPS - template/01_exports_flat/export_map.HEIC',
                    help='annotated capture-point map (HEIC, converted to PNG)')
    ap.add_argument('--unity', default='unity/CheddarAndCocoa', help='Unity project root')
    args = ap.parse_args()

    src = Path(args.source).expanduser().resolve()
    aerial_src = Path(args.aerial).expanduser().resolve()
    annotated_src = Path(args.annotated).expanduser().resolve()
    unity = Path(args.unity).expanduser().resolve()

    if not src.is_dir():
        print('ERROR: source photo folder not found:', src, file=sys.stderr)
        return 1
    if not unity.is_dir():
        print('ERROR: Unity project root not found:', unity, file=sys.stderr)
        return 1

    out = unity / 'Assets/Reference/BackyardCapture'
    map_dir = out / 'Map'
    sheets_dir = out / 'contact_sheets'
    out.mkdir(parents=True, exist_ok=True)
    map_dir.mkdir(parents=True, exist_ok=True)
    sheets_dir.mkdir(parents=True, exist_ok=True)

    # --- 1. Map assets -----------------------------------------------------
    aerial_ok = False
    aerial_dest = map_dir / 'Backyard_Aerial.png'
    if aerial_src.exists():
        shutil.copy2(aerial_src, aerial_dest)
        aerial_ok = True
    else:
        print('WARN: aerial map not found:', aerial_src, file=sys.stderr)

    annotated_dest = map_dir / 'export_map.png'
    annotated_ok, annotated_err = convert_heic_to_png(annotated_src, annotated_dest)
    if not annotated_ok:
        print('WARN: annotated map not converted:', annotated_err, file=sys.stderr)
        print('      Manual step: open', annotated_src.name,
              'in Preview, File > Export, format PNG, save as', annotated_dest, file=sys.stderr)

    aerial_size = image_pixel_size(aerial_dest) if aerial_ok else None

    # --- 2. Index reference photos ----------------------------------------
    photos = scan_photos(src)
    if not photos:
        print('ERROR: no JPG/PNG photos found in', src, file=sys.stderr)
        return 1

    images = []
    ungrouped = 0
    for p in photos:
        tk = tokens(p.stem)
        view_type, direction, tags, gameplay = classify(tk)
        pid = point_id_for(p.name)
        if pid is None:
            ungrouped += 1
        images.append({
            'filename': p.name,
            'original_file': str(p),
            'point_id': pid,
            'type': view_type,
            'direction': direction,
            'tags': tags,
            'gameplay_candidates': gameplay,
        })

    # --- 3. Emit data ------------------------------------------------------
    points_path = out / 'backyard_capture_points.json'
    existing_points = []
    if points_path.exists():
        try:
            existing_points = json.loads(points_path.read_text(encoding='utf-8')).get('points', [])
        except (ValueError, OSError):
            existing_points = []
    points = build_points(images, existing_points)

    generated_at = datetime.datetime.now().isoformat(timespec='seconds')
    manifest = {
        'area': 'backyard_main',
        'generated_at': generated_at,
        'source_root': str(src),
        'unity_root': str(unity),
        'output_root': str(out),
        'aerial_map_asset': 'Assets/Reference/BackyardCapture/Map/Backyard_Aerial.png' if aerial_ok else '',
        'annotated_map_asset': 'Assets/Reference/BackyardCapture/Map/export_map.png' if annotated_ok else '',
        'images': images,
        'points': points,
    }
    (out / 'backyard_manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    write_manifest_md(out / 'backyard_manifest.md', manifest)

    capture_points = {
        'area': 'backyard_main',
        'generated_at': generated_at,
        'aerial_map_asset': manifest['aerial_map_asset'],
        'annotated_map_asset': manifest['annotated_map_asset'],
        'aerial_pixel_size': ({'width': aerial_size[0], 'height': aerial_size[1]} if aerial_size else None),
        # map_position is normalized 0..1 over the aerial map: x left->right, y bottom->top.
        # placed=false means "not positioned yet" -> the editor parks it in the staging area.
        'position_space': 'normalized_0_1_origin_bottom_left',
        'points': points,
    }
    points_path.write_text(json.dumps(capture_points, indent=2), encoding='utf-8')

    # External browser contact sheets (reference originals, no in-Unity photo copies).
    write_contact_sheet(sheets_dir / 'contact_sheet_all.html',
                        'Backyard Reference — All', images)
    write_contact_sheet(sheets_dir / 'contact_sheet_overview.html',
                        'Backyard Reference — Overview / Layout',
                        [i for i in images if i['type'] == 'overview_high'])
    write_contact_sheet(sheets_dir / 'contact_sheet_dogview.html',
                        'Backyard Reference — Dog View Routes',
                        [i for i in images if i['type'] == 'dogview_route'])
    write_contact_sheet(sheets_dir / 'contact_sheet_interactive.html',
                        'Backyard Reference — Interactive Candidates',
                        [i for i in images if set(i['gameplay_candidates']) & INTERACTIVE_TAGS])

    # --- Ensure the Unity editor tool is present (never clobber edits) -----
    editor_dir = unity / 'Assets/Editor'
    editor_dir.mkdir(parents=True, exist_ok=True)
    builder_dest = editor_dir / 'BackyardGreyboxPlannerBuilder.cs'
    builder_src = Path(__file__).resolve().parents[2] / \
        'unity/CheddarAndCocoa/Assets/Editor/BackyardGreyboxPlannerBuilder.cs'
    if not builder_dest.exists() and builder_src.exists():
        shutil.copy2(builder_src, builder_dest)
        print('Installed editor tool:', builder_dest)

    # --- Report ------------------------------------------------------------
    placed = sum(1 for p in points if p['map_position'].get('placed'))
    print('Images indexed:      ', len(images), f'({ungrouped} ungrouped, no leading number)')
    print('Capture points:      ', len(points), f'({placed} placed on map, {len(points) - placed} in staging)')
    print('Aerial map copied:   ', 'yes' if aerial_ok else 'NO')
    print('Annotated map (PNG): ', 'yes' if annotated_ok else 'NO (see manual step above)')
    print('Output root:         ', out)
    print('Next: open Unity and run  Cheddar & Cocoa > Backyard > Build Map-Based Greybox Planner')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
